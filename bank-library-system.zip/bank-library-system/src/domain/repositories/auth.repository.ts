import User from "../../infrastructure/database/models/user/user.models";
import { RegisterUserDto } from "../../interfaces/types/user.interface";

const register = async (req: RegisterUserDto) => {
  try {
    await User.create({ ...req });
  } catch (error) {
    console.error("Error creating user:", error);
    throw new Error(String(error));
  }
};

export default {
  register
}