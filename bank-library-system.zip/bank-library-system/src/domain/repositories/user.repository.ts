import { User } from "../../infrastructure/database/models";

const get = async (attributes: string[], where: any): Promise<User | null> => {
  const user = await User.findOne({
    attributes,
    where,
  });
  return user;
};

export default {
  get
}