export { default as AuthRepository } from './auth.repository';
export { default as UserRepository } from './user.repository';
export { default as BookRepository } from './book.repository';