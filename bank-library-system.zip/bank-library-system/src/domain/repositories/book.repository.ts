import { Book } from "../../infrastructure/database/models";
import { transformBookItemDto } from "../../interfaces/dto/book.dto";
import { transformRawResult } from "../../interfaces/dto/common.dto";
import { BookCreateDto, BookItemDto, BookUpdateDto, FilterBook } from "../../interfaces/types/book.interface";
import { PaginationRequest } from "../../interfaces/types/request/common.request";
import { BookItemResponse } from "../../interfaces/types/response/book.response";
import { Op, OrderItem, QueryTypes, Transaction } from 'sequelize';

const create = async (req: BookCreateDto) => {
  try {
    await Book.create({ ...req });
  } catch (error) {
    console.error("Error creating book:", error);
    throw new Error(String(error));
  }
};

const update = async (req: BookUpdateDto) => {
  try {
    const [affected] = await Book.update(
      {
        name: req.name,
        book_type_code: req.book_type_code,
        author: req.author,
        published_date: req.published_date,
        updated_by: req.updated_by
      },
      {
        where: {
          id: req.id,
        },
      }
    );

    return affected;
  } catch (error) {
    console.error("Error updating book:", error);
    throw new Error(String(error));
  }
};

const getById = async (bookId: string) => {
  try {
    const book = await Book.findOne({
      where: {
        id: bookId,
      },
    });

    return book || null;
  } catch (error) {
    console.error('Error get book by id', error);
    throw new Error(String(error));
  }
};

const remove = async (bookId: string) => {
  try {
    const affected = await Book.destroy({
      where: {
        id: bookId,
      },
    });

    return affected;
  } catch (error) {
    console.error('error delete book', error);
    throw new Error(String(error));
  }
};

const getList = async (filter: FilterBook & PaginationRequest): Promise<{ rows: BookItemResponse[]; total: number } | null> => {
  try {
    let where = {};
    const conditionWhere: string | any[] = [];
    if (filter.search) {
      const searchSplit = filter.search.split(' ');
      const searchWhere = [];
      searchWhere.push({
        name: {
          [Op.iLike]: `%${filter.search}%`,
        },
      });
      searchWhere.push({
        author: {
          [Op.iLike]: `%${filter.search}%`,
        },
      });
      conditionWhere.push({
        [Op.or]: searchWhere,
      });
    }

    if (conditionWhere.length > 0) {
      where = {
        ...where,
        [Op.and]: conditionWhere,
      };
    }
    if (filter.bookTypeCode) {
      where = {
        ...where,
        book_type_code: filter.bookTypeCode,
      };
    }

    const { rows, count } = await Book.findAndCountAll({
      attributes: ['id', 'name', 'book_type_code', 'author', 'published_date', 'created_at'],
      where: {
        ...where,
      },
      offset: (filter.page - 1) * filter.perPage,
      limit: filter.perPage,
    }).then(transformRawResult<{ rows: BookItemDto[]; count: number }>);

    return {
      rows: rows ? transformBookItemDto(rows) : [],
      total: count,
    };
  } catch (error) {
    throw new Error(String(error));
  }
};


export default {
  create,
  update,
  getById,
  remove,
  getList,
}