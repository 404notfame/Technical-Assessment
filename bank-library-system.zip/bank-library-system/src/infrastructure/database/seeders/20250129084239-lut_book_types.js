'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('lut_book_types',[
      {
        name: 'Literature',
        code: 'BLS_BOOK_TYPE001',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Academic Books',
        code: 'BLS_BOOK_TYPE002',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Self-Improvement',
        code: 'BLS_BOOK_TYPE003',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Comics & Manga',
        code: 'BLS_BOOK_TYPE004',
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },

  async down (queryInterface, Sequelize) {}
};
