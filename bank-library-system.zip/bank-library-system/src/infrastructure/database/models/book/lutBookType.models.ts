import { DataTypes, Model } from 'sequelize';
import { sequelize } from '../../../database';
import { LutBookTypeAttribute, LutBookTypeInput } from '../../../../interfaces/types/lutBookType.interface';

class LutBookType extends Model<LutBookTypeAttribute, LutBookTypeInput> {
  public id!: number;
  public name!: string;
  public code!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
  public readonly deleted_at!: Date;
}

LutBookType.init(
  {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.INTEGER,
      autoIncrement: true,
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING(200),
    },
    code: {
      allowNull: false,
      type: DataTypes.STRING(50),
      unique: true,
    },
  },
  {
    sequelize,
    modelName: 'LutBookType',
    tableName: 'lut_book_types',
  }
);

export default LutBookType;
