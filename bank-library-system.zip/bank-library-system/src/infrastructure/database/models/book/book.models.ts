import { DataTypes, Model, UUIDV4 } from 'sequelize';
import { BookAttribute, BookInput } from '../../../../interfaces/types/book.interface';
import { sequelize } from '../../../database';
import LutBookType from './lutBookType.models';
import User from '../user/user.models';

class Book extends Model<BookAttribute, BookInput> {
  public id!: string;
  public name!: string;
  public book_type_code!: string;
  public author!: string;
  public published_date!: Date;
  public created_by!: string;
  public updated_by!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

Book.init(
  {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: UUIDV4,
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING(200),
    },
    book_type_code: {
      allowNull: true,
      type: DataTypes.STRING(50),
    },
    author: {
      allowNull: true,
      type: DataTypes.STRING(200),
    },
    published_date: {
      allowNull: true,
      type: DataTypes.DATE,
    },
    created_by: {
      allowNull: false,
      type: DataTypes.UUID,
    },
    updated_by: {
      allowNull: false,
      type: DataTypes.UUID,
    },
  },
  {
    sequelize,
    modelName: 'Book',
    tableName: 'books',
  }
);

Book.belongsTo(LutBookType, {
  foreignKey: {
    name: 'book_type_code',
    allowNull: true,
  },
  targetKey: 'code',
});

Book.belongsTo(User, {
  foreignKey: {
    name: 'created_by',
    allowNull: true,
  },
  targetKey: 'id',
});

Book.belongsTo(User, {
  foreignKey: {
    name: 'updated_by',
    allowNull: true,
  },
  targetKey: 'id',
});

export default Book;