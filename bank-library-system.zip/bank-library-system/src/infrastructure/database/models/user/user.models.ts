import { DataTypes, Model, UUIDV4 } from 'sequelize';
import { UserAttribute, UserInput } from '../../../../interfaces/types/user.interface';
import { sequelize } from '../../../database';

class User extends Model<UserAttribute, UserInput> {
  public id!: string;
  public first_name!: string;
  public last_name!: string;
  public username!: string;
  public password!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

User.init(
  {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: UUIDV4,
    },
    first_name: {
      allowNull: false,
      type: DataTypes.STRING(200),
    },
    last_name: {
      allowNull: false,
      type: DataTypes.STRING(200),
    },
    username: {
      allowNull: false,
      type: DataTypes.STRING(200),
      unique: true,
    },
    password: {
      allowNull: false,
      type: DataTypes.TEXT,
    },
  },
  {
    sequelize,
    modelName: 'User',
    tableName: 'users',
  }
);

export default User;
