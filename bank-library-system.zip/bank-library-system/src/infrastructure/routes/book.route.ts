import express from 'express';
import { authMiddleware } from '../middlewares/middleware';
import { bookCreateSchema, bookListSchema, bookUpdateSchema } from '../../shared/validator/book.validator';
import { validateSchemaMiddleware,JOI_OPTIONS } from '../middlewares/validation';
import { BookController } from '../controllers';

const bookRoute: express.Router = express.Router();

/**
 * POST /api/books
 * @security bearerAuth
 * @description Create a new book is successfully
 * @param {BookCreateRequest} request.body.required
 * @return {BookCreateResponse} 200 - success response - application/json
 * @return {ErrorResponse} 500 - Internal Server Error - application/json
 * @example response - 500 - internal server error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Create a new book failed"
 *   }
 * }
 * @return {ErrorResponse} 401 - unauthorized Error
 * @example response - 401 - unauthorized error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "UNAUTHORIZED",
 *     "message": "Can't create a new book"
 *   }
 * }
 */
bookRoute.post(
  '',
  authMiddleware(),
  validateSchemaMiddleware({
    options: JOI_OPTIONS.body,
    schema: bookCreateSchema,
  }),
  BookController.create
);

/**
 * PUT /api/books/:id
 * @security bearerAuth
 * @description Update a book is successfully
 * @param {BookCreateRequest} request.body.required
 * @return {BookCreateResponse} 200 - success response - application/json
 * @return {ErrorResponse} 500 - Internal Server Error - application/json
 * @example response - 500 - internal server error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Update a book failed"
 *   }
 * }
 * @return {ErrorResponse} 401 - unauthorized Error
 * @example response - 401 - unauthorized error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "UNAUTHORIZED",
 *     "message": "Can't update a book"
 *   }
 * }
 * @return {ErrorResponse} 404 - not found
 * @example response - 404 - book is not found
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "RECORD_NOT_FOUND",
 *     "message": "record not found"
 *   }
 * }
 */
bookRoute.put(
  '/:id',
  authMiddleware(),
  validateSchemaMiddleware({
    options: JOI_OPTIONS.body,
    schema: bookUpdateSchema,
  }),
  BookController.update
);

/**
 * DELETE /api/books/:id
 * @security bearerAuth
 * @description Delete a book is successfully
 * @param {BookCreateRequest} request.body.required
 * @return {BookCreateResponse} 200 - success response - application/json
 * @return {ErrorResponse} 500 - Internal Server Error - application/json
 * @example response - 500 - internal server error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Delete a book failed"
 *   }
 * }
 * @return {ErrorResponse} 401 - unauthorized Error
 * @example response - 401 - unauthorized error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "UNAUTHORIZED",
 *     "message": "Can't delete a book"
 *   }
 * }
 * @return {ErrorResponse} 404 - not found
 * @example response - 404 - book is not found
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "RECORD_NOT_FOUND",
 *     "message": "record not found"
 *   }
 * }
 */
bookRoute.delete(
  '/:id',
  authMiddleware(),
  BookController.remove
);

/**
 * GET /api/books
 * @security bearerAuth
 * @description Get books is successfully
 * @param {BookCreateRequest} request.body.required
 * @return {BookCreateResponse} 200 - success response - application/json
 * @return {ErrorResponse} 500 - Internal Server Error - application/json
 * @example response - 500 - internal server error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Get books failed"
 *   }
 * }
 * @return {ErrorResponse} 401 - unauthorized Error
 * @example response - 401 - unauthorized error response example
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "UNAUTHORIZED",
 *     "message": "Can't delete a book"
 *   }
 * }
 */
bookRoute.get(
  '',
  authMiddleware(),
  validateSchemaMiddleware({
    options: JOI_OPTIONS.query,
    schema: bookListSchema,
  }),
  BookController.getList
);

export default bookRoute;