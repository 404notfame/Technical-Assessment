import express from 'express';
import { AuthController } from '../controllers';
import { JOI_OPTIONS, validateSchemaMiddleware } from '../middlewares/validation';
import { loginSchema, registerSchema } from '../../shared/validator/auth.validator';

const authRoute: express.Router = express.Router();

/**
 * POST /api/auth/register
 * @description User register
 * @param {RegisterRequest} request.body.required
 * @return {SuccessResponse} 200 - success - application/json
 * @return {ErrorResponse} 400 - Bad request - application/json
 * @example response - 400 - Bad request
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "BAD_REQUEST",
 *     "message": "password is wrong"
 *   }
 * }
 * @return {ErrorResponse} 409 - Conflict - application/json
 * @example response - 409 - Conflict
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "CONFLICT",
 *     "message": "Status is deactivate"
 *   }
 * }
 * @return {ErrorResponse} 500 - Internal server error - application/json
 * @example response - 500 - Internal server error
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Can not auth login"
 *   }
 * }
 */
authRoute.post(
  '/register',
  validateSchemaMiddleware({
    options: JOI_OPTIONS.body,
    schema: registerSchema
  }),
  AuthController.register
);


/**
 * POST /api/auth/login
 * @description login by username and password
 * @param {LoginRequest} request.body.required
 * @return {LoginResponse} 200 - success response - application/json
 * @return {ErrorResponse} 400 - Bad request - application/json
 * @example response - 400 - Bad request
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "BAD_REQUEST",
 *     "message": "username/password is incorrect"
 *   }
 * }
 * @return {ErrorResponse} 404 - Not found - application/json
 * @example response - 404 - Not found
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "NOT_FOUND",
 *     "message": "User account is not found"
 *   }
 * }
 * @return {ErrorResponse} 500 - Internal server error - application/json
 * @example response - 500 - Internal server error
 * {
 *   "apiVersion": "1.0.0",
 *   "error": {
 *     "code": "INTERNAL_SERVER_ERROR",
 *     "message": "Login failed"
 *   }
 * }
 */
authRoute.post(
  '/login',
  validateSchemaMiddleware({
    options: JOI_OPTIONS.body,
    schema: loginSchema,
  }),
  AuthController.login
);

export default authRoute;