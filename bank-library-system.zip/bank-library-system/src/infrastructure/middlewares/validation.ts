import Joi from 'joi';
import { Request, NextFunction, Response, RequestHandler } from 'express';
import { api } from '../../shared/constants/api.constants';
import { errCode, errMessage } from '../../shared/constants/error.constants';

type JoiOptionsDataType = 'body' | 'params' | 'query';
type JoiOptionsType = {
  [key in JoiOptionsDataType]: JoiOptionsDataType;
};
export const JOI_OPTIONS: JoiOptionsType = {
  body: 'body',
  params: 'params',
  query: 'query',
};

export type ValidationType = {
  options: JoiOptionsDataType;
  schema: Joi.ObjectSchema | Joi.ArraySchema;
};

export interface ValidationResponse {
  [key: string]: any;
}

export const validateSchemaMiddleware = (validation: ValidationType): RequestHandler => {
  return (request: Request, response: Response, next: NextFunction): void => {
    try {
      Joi.attempt(request[validation.options], validation.schema);
    } catch (error) {
      const attribute: ValidationResponse = {};

      (error as Joi.ValidationError).details.forEach((detail: any) => {
        attribute[detail.context.key] = detail.message;
      });

      if (error) {
        response.status(400).json({
          apiVersion: api.API_VERSION_1,
          error: {
            code: errCode.BAD_REQUEST,
            message: errMessage.BAD_REQUEST,
            attribute,
          },
        });
        return;
      }
    }
    next();
  };
};
