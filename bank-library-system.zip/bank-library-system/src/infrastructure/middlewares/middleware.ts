import { Request, Response, NextFunction } from 'express';
import * as jwt from 'jsonwebtoken';
import { ResponseJWTType } from '../../interfaces/types/auth.interface';
import { errCode, errMessage } from '../../shared/constants/error.constants';
import { api } from '../../shared/constants/api.constants';
import httpContext from 'express-http-context';
import context from '../../shared/constants/context.constants';

export const authMiddleware = () => {
  return async (request: Request, response: Response, next: NextFunction): Promise<void> => {
    const token = request.headers['authorization']?.split(' ')[1];
    if (!token) { 
      response.status(401).json({
        apiVersion: api.API_VERSION_1,
        error: {
          code: errCode.UNAUTHORIZED,
          message: errMessage.UNAUTHORIZED,
        },
      });
      return;
    }

    const secret: string = process.env.SECRET_ACCESS_KEY ?? '';
    try {
      const responseVerify = jwt.verify(token, secret, {}) as unknown as ResponseJWTType;
      if (!responseVerify.userId) {
        response.status(403).json({
          apiVersion: api.API_VERSION_1,
          error: {
            code: errCode.INVALID_TOKEN,
            message: errMessage.INVALID_TOKEN,
          },
        });
        return;
      }

      httpContext.set(
        context.currentUser,
        {"id": responseVerify.userId}
      );
    } catch (error) {
      response.status(401).json({
        apiVersion: api.API_VERSION_1,
        error: {
          code: errCode.UNAUTHORIZED,
          message: errMessage.UNAUTHORIZED,
        },
      });
      return;
    }

    next();
  };
}