import * as dotenv from 'dotenv';

dotenv.config({ path: `${process.cwd()}/.env` });

export const NODE_ENV = process.env.NODE_ENV || 'development';
export const PORT = (process.env.PORT || 3000) as number;
export const DB_NAME = process.env.DB_NAME || '';
export const DB_HOST = process.env.DB_HOST || '';
export const DB_PORT = (process.env.DB_PORT || 5432) as number;
export const DB_USER = process.env.DB_USER || '';
export const DB_PASSWORD = process.env.DB_PASSWORD || '';

export const SECRET_ACCESS_KEY = process.env.SECRET_ACCESS_KEY || '';
export const SECRET_REFRESH_KEY = process.env.SECRET_REFRESH_KEY || '';