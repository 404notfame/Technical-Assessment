import express from 'express';
import helmet from 'helmet';
import expressJSDocSwagger from 'express-jsdoc-swagger';
import httpContext from 'express-http-context';

import { PORT } from './dotenv';
import { swaggerOptions } from './swagger';
import logger from '../../shared/utils/logger.utils';

export default () => {
  const app = express();
  app.use(
    helmet({
      contentSecurityPolicy: false,
    })
  );
  
  app.use((_, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH');
    res.header('Access-Control-Allow-Headers', 'Content-Type,Authorization,Content-disposition');
    next();
  });
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(express.static('public'));
  app.use(httpContext.middleware as unknown as express.RequestHandler);

  expressJSDocSwagger(app)(swaggerOptions);

  app.listen(PORT, () => {
    logger.logInfo(`Server is running on port ${PORT}.`);
  });

  return app;
};
