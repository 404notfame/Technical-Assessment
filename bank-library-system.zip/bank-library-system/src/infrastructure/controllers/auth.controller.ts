import { ControllerBaseFunctionType } from '../../interfaces/types/controller.interface'
import { LoginRequest, RegisterRequest } from '../../interfaces/types/request/auth.request';
import { api } from '../../shared/constants/api.constants';
import logger from '../../shared/utils/logger.utils';
import { AuthService } from '../../application/services'

const register: ControllerBaseFunctionType<RegisterRequest, {}, {}> = async (req, res) => {
  logger.start(req);

  const registerResponse = await AuthService.register(req.body);

  if (registerResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'User register',
        description: 'Register is successfully',
      },
    });
  }

  if (registerResponse.isErr()) {
    res.status(500).json({
      apiVersion: api.API_VERSION_1,
      error: {
        code: registerResponse.error.code,
        message: 'Register failed',
      },
    });
  }

  logger.end(req);
};

const login: ControllerBaseFunctionType<LoginRequest, {}, {}> = async (req, res) => {
  logger.start(req);

  const loginResponse = await AuthService.login(req.body);

  if (loginResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'User login',
        description: 'Login is successfully',
        item: loginResponse.value,
      },
    });
  }

  if (loginResponse.isErr()) {
    res.status(500).json({
      apiVersion: api.API_VERSION_1,
      error: {
        code: loginResponse.error.code,
        message: 'Login failed',
      },
    });
  }

  logger.end(req);
};

export default {
  register,
  login
}