import { ControllerBaseFunctionType } from '../../interfaces/types/controller.interface'
import { api } from '../../shared/constants/api.constants';
import logger from '../../shared/utils/logger.utils';
import { BookService } from '../../application/services'
import httpContext from 'express-http-context';
import context from '../../shared/constants/context.constants';
import { BookCreateRequest, BookUpdateRequest } from '../../interfaces/types/request/book.request';
import { errCode } from '../../shared/constants/error.constants';
import { FilterBook } from '../../interfaces/types/book.interface';
import { PaginationRequest } from '../../interfaces/types/request/common.request';

const create: ControllerBaseFunctionType<BookCreateRequest, {}, {}> = async (req, res) => {
  logger.start(req);

  const currentUser = httpContext.get(context.currentUser);
  const createResponse = await BookService.create(currentUser.id,req.body);

  if (createResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'Create a new book',
        description: 'Create a new book is successfully',
      },
    });
  }

  if (createResponse.isErr()) {
    res.status(500).json({
      apiVersion: api.API_VERSION_1,
      error: {
        code: createResponse.error.code,
        message: 'Create a new book is failed',
      },
    });
  }

  logger.end(req);
};

const update: ControllerBaseFunctionType<BookUpdateRequest, {}, {}> = async (req, res) => {
  logger.start(req);

  const { id } = req.params;
  req.body.id = id

  const currentUser = httpContext.get(context.currentUser);
  const updateResponse = await BookService.update(currentUser.id,req.body);

  if (updateResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'Update a book',
        description: 'Update a book is successfully',
      },
    });
  }

  if (updateResponse.isErr()) {
    res.status(500).json({
      apiVersion: api.API_VERSION_1,
      error: {
        code: updateResponse.error.code,
        message: 'Update new book is failed',
      },
    });
  }

  logger.end(req);
};

const remove: ControllerBaseFunctionType<{}, {}, {}> = async (req, res) => {
  logger.start(req);

  const { id } = req.params;
  req.body.id = id

  const deleteResponse = await BookService.remove(id);

  if (deleteResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'Delete a book',
        description: 'Delete a book is successfully',
      },
    });
  }

  if (deleteResponse.isErr()) {
    res.status(500).json({
      apiVersion: api.API_VERSION_1,
      error: {
        code: deleteResponse.error.code,
        message: 'Delete new book is failed',
      },
    });
  }

  logger.end(req);
};

const getList: ControllerBaseFunctionType<{}, {}, FilterBook & PaginationRequest> = async (req, res) => {
  logger.start(req);

  const filter = req.query
  const getListResponse = await BookService.getList(filter);

  if (getListResponse.isOk()) {
    res.status(200).json({
      apiVersion: api.API_VERSION_1,
      data: {
        title: 'Get books',
        description: 'Get books is successfully',
        items: getListResponse.value.items,
        pagination: getListResponse.value.pagination,
      },
    });
  }

  if (getListResponse.isErr()) {
    if (getListResponse.error.code === errCode.BAD_REQUEST) {
      res.status(400).json({
        apiVersion: api.API_VERSION_1,
        error: {
          code: errCode.BAD_REQUEST,
          message: 'Get books filed',
        },
      });
    } else {
      res.status(500).json({
        apiVersion: api.API_VERSION_1,
        error: {
          code: errCode.INTERNAL_SERVER_ERROR,
          message: 'Get books filed',
        },
      });
    }
  }

  logger.end(req);
};

export default {
  create,
  update,
  remove,
  getList,
}