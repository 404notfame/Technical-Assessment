import path from 'path';
import Express from 'express';

import express from './infrastructure/config/express';
import router from "./infrastructure/routes";
import { sequelize } from './infrastructure/database';


const app = express();

app.get('/api/health', async (_req, res) => {
  try {
    await sequelize.authenticate();
    res.status(200).send({ 
      status: 'UP',
      message: 'Health check successfully',
    });
  } catch (error) {
    res.status(500).send({
      status: 'DOWN',
      message: 'Health check failed: Unable to connect Database',
    });
  }
});

app.use('/api/docs', Express.static(path.join(__dirname, '/public/docs.html')));

app.use('/api', router);