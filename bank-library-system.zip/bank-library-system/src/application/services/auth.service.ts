import { err, ok, Result } from 'neverthrow';
import { LoginRequest, RegisterRequest } from '../../interfaces/types/request/auth.request';
import { ResponseErrorType } from '../../interfaces/types/response/common.response';
import { errCode } from '../../shared/constants/error.constants';
import { AuthRepository, UserRepository } from '../../domain/repositories';
import { compareSync, genSalt, hash } from 'bcryptjs';
import { genAccessToken, genRefreshToken } from '../../shared/utils/token.utils';
import { LoginResponse } from '../../interfaces/types/response/auth.response';

const register = async (
  req: RegisterRequest
): Promise<Result<null, ResponseErrorType>> => {
  try {
    if (req.password !== req.confirmPassword) {
      console.error('Register password or confirm password is wrong');
      return err({
        code: errCode.CONFLICT,
      });
    }
    const salt = await genSalt(12);
    const hashPassword = await hash(req.password, salt);

    await AuthRepository.register({
      first_name: req.firstName,
      last_name: req.lastName,
      username: req.username,
      password: hashPassword
    })
    return ok(null);
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};

const login = async (
  req: LoginRequest
): Promise<Result<LoginResponse, ResponseErrorType>> => {
  try {
    const user = await UserRepository.get(
      [
        'id',
        'first_name',
        'last_name',
        'password',
      ],
      {
        username: req.username,
      }
    );
    
    const isMatch = compareSync(req.password, user?.password || '');
    if (!isMatch) {
      return err({
        code: errCode.RECORD_NOT_FOUND,
      });
    }

    const accessToken: string = await genAccessToken({
      userId: user?.id || '',
    });
    const refreshToken: string = await genRefreshToken({
      userId: user?.id || '',
    });

    return ok({accessToken, refreshToken});
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};

export default {
  register,
  login
}