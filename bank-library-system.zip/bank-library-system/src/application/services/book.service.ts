import { err, ok, Result } from 'neverthrow';
import { ResponseErrorType } from '../../interfaces/types/response/common.response';
import { errCode } from '../../shared/constants/error.constants';
import { BookRepository } from '../../domain/repositories';
import { BookCreateRequest, BookUpdateRequest } from '../../interfaces/types/request/book.request';
import { BookListResponse, setPaginate } from '../../interfaces/types/response/book.response';
import { FilterBook } from '../../interfaces/types/book.interface';
import { PaginationRequest } from '../../interfaces/types/request/common.request';


const create = async (
  userId: string,
  req: BookCreateRequest
): Promise<Result<null, ResponseErrorType>> => {
  try {
    await BookRepository.create({
      name: req.name,
      book_type_code: req.bookTypeCode,
      author: req.author,
      published_date: req.publishedDate,
      created_by: userId,
      updated_by: userId,
    })
    return ok(null);
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};

const update = async (
  userId: string,
  req: BookUpdateRequest
): Promise<Result<null, ResponseErrorType>> => {
  try {
    const affected = await BookRepository.update({
      id: req.id,
      name: req.name,
      book_type_code: req.bookTypeCode,
      author: req.author,
      published_date: req.publishedDate,
      updated_by: userId,
    })
    if (affected === 0) {
      return err({
        code: errCode.INTERNAL_SERVER_ERROR,
      });
    }
    return ok(null);
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};

const remove = async (bookId: string): Promise<Result<null, ResponseErrorType>> => {
  try {
    
    const book = await BookRepository.getById(bookId);

    if (!book) {
      return err({
        code: errCode.NOT_FOUND,
        message: 'book not found',
      });
    }

    const affected = await BookRepository.remove(bookId)
    if (affected === 0) {
      return err({
        code: errCode.INTERNAL_SERVER_ERROR,
      });
    }

    return ok(null);
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};

const getList = async (filter: FilterBook & PaginationRequest): Promise<Result<BookListResponse, ResponseErrorType>> => {
  try {
    filter.page = filter.page || 1;
    filter.perPage = filter.perPage || 10;

    const res = await BookRepository.getList(filter);
    return ok({
      items: res!.rows,
      pagination: setPaginate(filter.page, filter.perPage, res!.total),
    });
  } catch (error) {
    return err({
      code: errCode.INTERNAL_SERVER_ERROR,
    });
  }
};


export default {
  create,
  update,
  remove,
  getList,
}