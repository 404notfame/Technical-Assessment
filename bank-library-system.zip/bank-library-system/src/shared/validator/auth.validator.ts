import Joi from 'joi';

export const registerSchema: Joi.ObjectSchema = Joi.object().keys({
  firstName: Joi.string().required(),
  lastName: Joi.string().required(),
  username: Joi.string().required(),
  password: Joi.string().required(),
  confirmPassword: Joi.string().required(),
});

export const loginSchema: Joi.ObjectSchema = Joi.object().keys({
  username: Joi.string().required(),
  password: Joi.string().required(),
});