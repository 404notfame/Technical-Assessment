import Joi from 'joi';
import { LutBookTypeEnum } from '../../interfaces/enum/lutBookType.enum';

export const bookCreateSchema: Joi.ObjectSchema = Joi.object().keys({
  name: Joi.string().required(),
  bookTypeCode: Joi.string(),
  author: Joi.string(),
  publishedDate: Joi.string(),
});

export const bookUpdateSchema: Joi.ObjectSchema = Joi.object().keys({
  name: Joi.string().required(),
  bookTypeCode: Joi.string().required(),
  author: Joi.string().required(),
  publishedDate: Joi.string().required(),
});

export const bookListSchema: Joi.ObjectSchema = Joi.object().keys({
  search: Joi.string(),
  bookTypeCode: Joi.string()
    .optional()
    .valid(...Object.values(LutBookTypeEnum)),
  page: Joi.number(),
  perPage: Joi.number(),
});