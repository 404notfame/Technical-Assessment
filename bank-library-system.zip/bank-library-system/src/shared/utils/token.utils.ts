import * as jwt from 'jsonwebtoken';
import { SECRET_ACCESS_KEY, SECRET_REFRESH_KEY } from '../../infrastructure/config/dotenv';
import { ResponseJWTType } from '../../interfaces/types/auth.interface';

export const genAccessToken = async (req: ResponseJWTType): Promise<string> => {
  return jwt.sign(req, SECRET_ACCESS_KEY, {
    expiresIn: '1d'
  })
};

export const genRefreshToken = async (req: ResponseJWTType): Promise<string> => {
  return jwt.sign(req, SECRET_REFRESH_KEY, {
    expiresIn: '1w',
  });
};
