export const errCode = {
  INTERNAL_SERVER_ERROR: 'INTERNAL_SERVER_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  BAD_REQUEST: 'BAD_REQUEST',
  CONFLICT: 'CONFLICT',
  NO_PERMISSION: 'PERMISSION_DENIED',
  RECORD_NOT_FOUND: 'RECORD_NOT_FOUND',
  UNAUTHORIZED: 'UNAUTHORIZED',
  INVALID_TOKEN: 'INVALID_TOKEN',
};

export const errMessage = {
  NO_PERMISSION: `You're not allowed to access`,
  NOT_FOUND: 'Record not found',
  UNAUTHORIZED: 'Unauthorized',
  CONFLICT: 'Conflict some condition',
  INVALID_TOKEN: 'Invalid token',
  BAD_REQUEST: 'Bad request',
};