export const api = {
  API_VERSION_1: '1.0.0',
};