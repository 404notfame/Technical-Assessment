const context = {
  currentUser: 'currentUser'
};

export default context;
