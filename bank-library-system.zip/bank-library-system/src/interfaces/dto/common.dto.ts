export function transformRawResult<T>(input: any) {
  return input as T;
}