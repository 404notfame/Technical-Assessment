import { BookItemDto } from "../types/book.interface";
import { BookItemResponse } from "../types/response/book.response";

export const transformBookItemDto = (input: BookItemDto[]): BookItemResponse[] => {
  return input.map((item: BookItemDto): BookItemResponse => {
    return {
      id: item.id,
      name: item.name,
      bookTypeCode: item.book_type_code,
      author: item.author,
      publishedDate: item.published_date,
      createdAt: item.created_at,
    };
  });
};