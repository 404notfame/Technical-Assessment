export interface ResponseErrorType {
  code: string;
  message?: string;
};

export type PaginationResponse = {
  total: number;
  previousPage?: number | null;
  currentPage: number;
  nextPage?: number | null;
  lastPage: number;
  perPage: number;
};