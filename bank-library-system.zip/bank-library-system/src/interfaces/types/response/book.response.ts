import { PaginationResponse } from "./common.response";

export interface BookCreateResponse {
  id: string;
}

export interface BookListResponse {
  items: BookItemResponse[]
  pagination: PaginationResponse;
}

export const setPaginate = (page: number, perPage: number, total: number): PaginationResponse => {
  const lastPage = +Math.ceil(total / perPage);
  return {
    total,
    previousPage: +page > 1 ? page - 1 : null,
    currentPage: +page,
    nextPage: page < lastPage ? +page + 1 : null,
    lastPage,
    perPage: +perPage,
  };
};

export interface BookItemResponse {
  id: string;
  name: string;
  bookTypeCode: string;
  author: string;
  publishedDate: Date
  createdAt: Date
}