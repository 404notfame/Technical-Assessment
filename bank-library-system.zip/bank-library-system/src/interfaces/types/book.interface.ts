import { Optional } from 'sequelize';

export type BookAttribute = {
  id: string;
  name?: string;
  book_type_code?: string;
  author?: string;
  published_date?: Date;
  created_by?: string;
  updated_by?: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
};

export type BookInput = Optional<BookAttribute, 'id'>;

export interface BookCreateDto {
  name: string;
  book_type_code?: string;
  author?: string;
  published_date?: Date;
  created_by?: string;
  updated_by?: string;
}

export interface BookUpdateDto {
  id: string;
  name: string;
  book_type_code?: string;
  author?: string;
  published_date?: Date;
  updated_by?: string;
}

export interface FilterBook {
  search?: string;
  bookTypeCode?: string;
}

export interface BookItemDto {
  id: string;
  name: string;
  book_type_code: string;
  author: string;
  published_date: Date;
  created_at: Date;
}
