import { Optional } from 'sequelize';

export type UserAttribute = {
  id: string;
  first_name?: string;
  last_name?: string;
  username?: string;
  password?: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
};

export type UserInput = Optional<UserAttribute, 'id'>;

export interface RegisterUserDto {
  first_name: string;
  last_name: string;
  username: string;
  password: string;
}
