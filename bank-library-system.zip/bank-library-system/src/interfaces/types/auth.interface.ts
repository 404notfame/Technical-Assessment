export interface ResponseJWTType {
  userId: string;
};