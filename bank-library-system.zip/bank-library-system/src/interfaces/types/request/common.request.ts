export interface PaginationRequest {
  page: number;
  perPage: number;
  search: string;
}