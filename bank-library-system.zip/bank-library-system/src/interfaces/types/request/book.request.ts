export interface BookCreateRequest {
  name: string;
  bookTypeCode: string;
  author: string;
  publishedDate: Date;
}

export interface BookUpdateRequest {
  id: string;
  name: string;
  bookTypeCode: string;
  author: string;
  publishedDate: Date;
}