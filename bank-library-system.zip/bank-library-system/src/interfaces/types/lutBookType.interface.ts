import { Optional } from 'sequelize';

export type LutBookTypeAttribute = {
  id: number;
  name: string;
  code: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
};

export type LutBookTypeInput = Optional<LutBookTypeAttribute, 'id'>;
